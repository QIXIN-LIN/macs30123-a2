class CommandError(Exception):
    pass
